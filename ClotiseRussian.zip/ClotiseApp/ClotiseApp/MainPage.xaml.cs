﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Controls.Primitives;

namespace Clock.App
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Секундомер
        private DispatcherTimer stopwatchTimer;
        private DateTime stopwatchStartTime;
        private bool isStopwatchRunning;
        private List<LapInfo> laps;
        private int lapCounter;
        private TimeSpan totalElapsedBeforePause;

        // Таймер
        private DispatcherTimer countdownTimer;
        private TimeSpan countdownTime;
        private bool isCountdownRunning;
        private bool isCountdownPaused;
        private TimeSpan originalCountdownTime;
        private string originalTimerText;

        // Таймер для остановки звука
        private DispatcherTimer alarmStopTimer;

        public MainPage()
        {
            InitializeComponent();

            InitializeStopwatch();
            InitializeCountdown();
            InitializeAlarmStopTimer();
            InitializeTimeSelectors();
        }

        #region Инициализация LoopingSelector
        private void InitializeTimeSelectors()
        {
            // Создаем и устанавливаем источники данных
            HoursSelector.DataSource = new NumberDataSource(0, 23);
            MinutesSelector.DataSource = new NumberDataSource(0, 59);
            SecondsSelector.DataSource = new NumberDataSource(0, 59);

            // Устанавливаем начальные значения
            HoursSelector.DataSource.SelectedItem = "00";
            MinutesSelector.DataSource.SelectedItem = "00";
            SecondsSelector.DataSource.SelectedItem = "00";
        }

        // Класс-источник данных для LoopingSelector
        public class NumberDataSource : ILoopingSelectorDataSource
        {
            private List<string> items;
            private int selectedIndex;
            private object selectedItem;

            public NumberDataSource(int min, int max)
            {
                items = new List<string>();
                for (int i = min; i <= max; i++)
                {
                    items.Add(i.ToString("00"));
                }
                selectedIndex = 0;
                selectedItem = items[0];
            }

            public object GetNext(object relativeTo)
            {
                int index = items.IndexOf(relativeTo.ToString());
                return items[(index + 1) % items.Count];
            }

            public object GetPrevious(object relativeTo)
            {
                int index = items.IndexOf(relativeTo.ToString());
                return items[(index - 1 + items.Count) % items.Count];
            }

            public object SelectedItem
            {
                get { return selectedItem; }
                set
                {
                    if (value != selectedItem)
                    {
                        selectedItem = value;
                        var handler = SelectionChanged;
                        if (handler != null)
                        {
                            handler(this, new SelectionChangedEventArgs(new List<object>(), new List<object>()));
                        }
                    }
                }
            }

            public event EventHandler<SelectionChangedEventArgs> SelectionChanged;
        }
        #endregion

        #region Секундомер
        private void InitializeStopwatch()
        {
            stopwatchTimer = new DispatcherTimer();
            stopwatchTimer.Interval = TimeSpan.FromMilliseconds(10);
            stopwatchTimer.Tick += StopwatchTimer_Tick;
            laps = new List<LapInfo>();
            totalElapsedBeforePause = TimeSpan.Zero;

            // Установка начального отображения
            StopwatchMainTime.Text = "00:00:00";
            StopwatchMilliseconds.Text = ",00";
        }

        private void StopwatchTimer_Tick(object sender, EventArgs e)
        {
            TimeSpan elapsed = DateTime.Now - stopwatchStartTime + totalElapsedBeforePause;
            UpdateStopwatchDisplay(elapsed);
        }

        private void UpdateStopwatchDisplay(TimeSpan elapsed)
        {
            // Основное время (часы, минуты, секунды)
            StopwatchMainTime.Text = string.Format("{0:00}:{1:00}:{2:00}",
                (int)elapsed.TotalHours,
                elapsed.Minutes,
                elapsed.Seconds);

            // Миллисекунды меньшим шрифтом
            StopwatchMilliseconds.Text = string.Format(",{0:00}",
                elapsed.Milliseconds / 10);
        }

        private void StartStopButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isStopwatchRunning)
            {
                StartStopwatch();
            }
            else
            {
                StopStopwatch();
            }
        }

        private void ResetLapButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isStopwatchRunning)
            {
                ResetStopwatch();
            }
            else
            {
                RecordLap();
            }
        }

        private void StartStopwatch()
        {
            stopwatchStartTime = DateTime.Now;
            stopwatchTimer.Start();
            isStopwatchRunning = true;
            StartStopButton.Content = "стоп";
            ResetLapButton.Content = "круг";
        }

        private void StopStopwatch()
        {
            stopwatchTimer.Stop();
            totalElapsedBeforePause += DateTime.Now - stopwatchStartTime;
            isStopwatchRunning = false;
            StartStopButton.Content = "старт";
            ResetLapButton.Content = "сброс";
        }

        private void ResetStopwatch()
        {
            stopwatchTimer.Stop();
            StopwatchMainTime.Text = "00:00:00";
            StopwatchMilliseconds.Text = ",00";
            laps.Clear();
            LapsList.ItemsSource = null;
            lapCounter = 0;
            totalElapsedBeforePause = TimeSpan.Zero;
            isStopwatchRunning = false;
            StartStopButton.Content = "старт";
            ResetLapButton.Content = "сброс";
        }

        private void RecordLap()
        {
            lapCounter++;
            TimeSpan currentElapsed = DateTime.Now - stopwatchStartTime + totalElapsedBeforePause;
            string lapTime = FormatTimeWithHours(currentElapsed, true);

            laps.Add(new LapInfo
            {
                LapNumber = "круг " + lapCounter,
                Time = lapTime
            });
            LapsList.ItemsSource = null;
            LapsList.ItemsSource = laps;
        }
        #endregion

        #region Таймер
        private void InitializeCountdown()
        {
            countdownTimer = new DispatcherTimer();
            countdownTimer.Interval = TimeSpan.FromSeconds(1);
            countdownTimer.Tick += CountdownTimer_Tick;
            countdownTime = TimeSpan.Zero;
            originalCountdownTime = TimeSpan.Zero;
            isCountdownPaused = false;

            // Изначально показываем только панель выбора времени
            TimerCountdown.Visibility = Visibility.Collapsed;
            TimeSelectionPanel.Visibility = Visibility.Visible;
        }

        private void InitializeAlarmStopTimer()
        {
            alarmStopTimer = new DispatcherTimer();
            alarmStopTimer.Interval = TimeSpan.FromSeconds(90);
            alarmStopTimer.Tick += AlarmStopTimer_Tick;
        }

        private void AlarmStopTimer_Tick(object sender, EventArgs e)
        {
            // Остановить звук через 90 секунд (на всякий случай)
            alarmStopTimer.Stop();
            AlarmSound.Stop();
        }

        private void CountdownTimer_Tick(object sender, EventArgs e)
        {
            if (countdownTime > TimeSpan.Zero)
            {
                countdownTime = countdownTime.Subtract(TimeSpan.FromSeconds(1));
                UpdateCountdownDisplay();
            }
            else
            {
                countdownTimer.Stop();
                isCountdownRunning = false;
                isCountdownPaused = false;
                ShowTimerStoppedState();

                // Воспроизведение звука (один раз)
                AlarmSound.Play();

                // Запустить таймер для автоматической остановки звука через 90 секунд
                alarmStopTimer.Start();

                // Показать сообщение с исходным временем в заголовке
                MessageBoxResult result = MessageBox.Show("Таймер был установлен на " + originalTimerText + ".",
                               "Время вышло!",
                               MessageBoxButton.OK);

                // Остановить звук после закрытия MessageBox
                AlarmSound.Stop();
                alarmStopTimer.Stop();

                // Вернуть отображение панели выбора времени
                TimeSelectionPanel.Visibility = Visibility.Visible;
                TimerCountdown.Visibility = Visibility.Collapsed;
            }
        }

        private void UpdateCountdownDisplay()
        {
            TimerCountdown.Text = FormatTimeWithHours(countdownTime, false);

            // Меняем цвет текста, если осталось 5 секунд или меньше
            if (countdownTime.TotalSeconds <= 5 && countdownTime.TotalSeconds > 0)
            {
                TimerCountdown.Foreground = (SolidColorBrush)Application.Current.Resources["PhoneAccentBrush"];
            }
            else
            {
                TimerCountdown.Foreground = (SolidColorBrush)Application.Current.Resources["PhoneForegroundBrush"];
            }
        }

        // Состояние: таймер не запущен
        private void ShowTimerStoppedState()
        {
            TimerStartButton.Visibility = Visibility.Visible;
            TimerStopButton.Visibility = Visibility.Collapsed;
            TimerPauseButton.Visibility = Visibility.Collapsed;
            TimerResetButton.Visibility = Visibility.Collapsed;
            TimerResumeButton.Visibility = Visibility.Collapsed;

            TimerStartButton.SetValue(Grid.ColumnSpanProperty, 3);
        }

        // Состояние: таймер запущен
        private void ShowTimerRunningState()
        {
            TimerStartButton.Visibility = Visibility.Collapsed;
            TimerStopButton.Visibility = Visibility.Visible;
            TimerPauseButton.Visibility = Visibility.Visible;
            TimerResetButton.Visibility = Visibility.Collapsed;
            TimerResumeButton.Visibility = Visibility.Collapsed;
        }

        // Состояние: таймер на паузе
        private void ShowTimerPausedState()
        {
            TimerStartButton.Visibility = Visibility.Collapsed;
            TimerStopButton.Visibility = Visibility.Collapsed;
            TimerPauseButton.Visibility = Visibility.Collapsed;
            TimerResetButton.Visibility = Visibility.Visible;
            TimerResumeButton.Visibility = Visibility.Visible;
        }

        private void TimerStartButton_Click(object sender, RoutedEventArgs e)
        {
            StartCountdown();
        }

        private void TimerStopButton_Click(object sender, RoutedEventArgs e)
        {
            StopCountdown();
        }

        private void TimerPauseButton_Click(object sender, RoutedEventArgs e)
        {
            PauseCountdown();
        }

        private void TimerResetButton_Click(object sender, RoutedEventArgs e)
        {
            ResetCountdown();
        }

        private void TimerResumeButton_Click(object sender, RoutedEventArgs e)
        {
            ResumeCountdown();
        }

        private void StartCountdown()
        {
            // Получить время из LoopingSelector
            int hours = 0;
            int minutes = 0;
            int seconds = 0;

            if (HoursSelector.DataSource.SelectedItem != null)
                int.TryParse(HoursSelector.DataSource.SelectedItem.ToString(), out hours);
            if (MinutesSelector.DataSource.SelectedItem != null)
                int.TryParse(MinutesSelector.DataSource.SelectedItem.ToString(), out minutes);
            if (SecondsSelector.DataSource.SelectedItem != null)
                int.TryParse(SecondsSelector.DataSource.SelectedItem.ToString(), out seconds);

            countdownTime = new TimeSpan(hours, minutes, seconds);
            originalCountdownTime = countdownTime;
            originalTimerText = FormatTimeWithHours(countdownTime, false);

            if (countdownTime > TimeSpan.Zero)
            {
                countdownTimer.Start();
                isCountdownRunning = true;
                isCountdownPaused = false;

                // Переключение видимости: скрыть панель выбора, показать отсчет
                TimeSelectionPanel.Visibility = Visibility.Collapsed;
                TimerCountdown.Visibility = Visibility.Visible;

                // Показать состояние "таймер запущен"
                ShowTimerRunningState();

                UpdateCountdownDisplay();
            }
        }

        private void StopCountdown()
        {
            countdownTimer.Stop();
            isCountdownRunning = false;
            isCountdownPaused = false;

            // Показать состояние "таймер остановлен"
            ShowTimerStoppedState();

            // Переключение видимости: показать панель выбора, скрыть отсчет
            TimeSelectionPanel.Visibility = Visibility.Visible;
            TimerCountdown.Visibility = Visibility.Collapsed;

            // Остановка звука, если он играет
            AlarmSound.Stop();
            alarmStopTimer.Stop();
        }

        private void PauseCountdown()
        {
            if (isCountdownRunning && !isCountdownPaused)
            {
                countdownTimer.Stop();
                isCountdownRunning = false;
                isCountdownPaused = true;

                // Показать состояние "таймер на паузе"
                ShowTimerPausedState();
            }
        }

        private void ResumeCountdown()
        {
            if (isCountdownPaused)
            {
                countdownTimer.Start();
                isCountdownRunning = true;
                isCountdownPaused = false;

                // Показать состояние "таймер запущен"
                ShowTimerRunningState();
            }
        }

        private void ResetCountdown()
        {
            countdownTimer.Stop();
            isCountdownRunning = false;
            isCountdownPaused = false;

            // Показать состояние "таймер остановлен"
            ShowTimerStoppedState();

            // Переключение видимости: показать панель выбора, скрыть отсчет
            TimeSelectionPanel.Visibility = Visibility.Visible;
            TimerCountdown.Visibility = Visibility.Collapsed;

            // Остановка звука, если он играет
            AlarmSound.Stop();
            alarmStopTimer.Stop();

            // НЕ сбрасываем выбор времени, чтобы пользователь мог снова запустить с тем же временем
            // HoursSelector.DataSource.SelectedItem = "00";
            // MinutesSelector.DataSource.SelectedItem = "00";
            // SecondsSelector.DataSource.SelectedItem = "00";
        }
        #endregion

        #region Вспомогательные методы
        private string FormatTimeWithHours(TimeSpan time, bool includeMilliseconds)
        {
            if (includeMilliseconds)
            {
                return string.Format("{0:00}:{1:00}:{2:00},{3:00}",
                    (int)time.TotalHours,
                    time.Minutes,
                    time.Seconds,
                    time.Milliseconds / 10);
            }
            else
            {
                return string.Format("{0:00}:{1:00}:{2:00}",
                    (int)time.TotalHours,
                    time.Minutes,
                    time.Seconds);
            }
        }
        #endregion
    }

    public class LapInfo
    {
        public string LapNumber { get; set; }
        public string Time { get; set; }
    }
}